package com.telecome.project.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.telecome.project.entity.TechnicalIssue;

@Repository
public interface TechnicalIssueRepository extends CrudRepository<TechnicalIssue, String> {

}
