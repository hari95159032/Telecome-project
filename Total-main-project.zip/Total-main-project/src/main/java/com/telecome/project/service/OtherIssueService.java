package com.telecome.project.service;

import com.telecome.project.entity.OtherIssue;

public interface OtherIssueService {
	
	public void otherIssue(OtherIssue otherIssue, Integer id);

}
