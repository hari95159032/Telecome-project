package com.telecome.project.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.telecome.project.entity.OtherIssue;
import com.telecome.project.service.OtherIssueServiceImpl;

@RestController
@RequestMapping("api/other")
@CrossOrigin("*")
public class OtherIssueController {
	
	@Autowired
	OtherIssueServiceImpl service;
	
	@PostMapping("/{id}")
	public void otherIssue(@RequestBody OtherIssue otherIssue, @PathVariable Integer id) {
		service.otherIssue(otherIssue, id);
	}
	

}
