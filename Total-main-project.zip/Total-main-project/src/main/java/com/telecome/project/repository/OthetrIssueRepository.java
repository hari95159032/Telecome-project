package com.telecome.project.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.telecome.project.entity.OtherIssue;

@Repository
public interface OthetrIssueRepository extends CrudRepository<OtherIssue, String> {

}
