package com.telecome.project.service;

import java.sql.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.telecome.project.entity.BillingIssue;
import com.telecome.project.entity.User;
import com.telecome.project.repository.BillingIssuerepository;
@Service
public class BillingIssueServiceImpl implements BillingIssueService{

	BillingIssuerepository repository;
	
	@Autowired
	public void setRepository(BillingIssuerepository repository) {
		this.repository = repository;
	}
	
	@Override
	public void billingIssue(BillingIssue billIssue, Integer id) {

		billIssue.setUser(new User(id));
		repository.save(billIssue);
		System.out.println(billIssue);
		System.out.println(billIssue.getBillingIssueId());
		
	}

}
