package com.telecome.project.service;

import com.telecome.project.entity.User;

public interface UserService {

	public String signUp(User user);
	
	public Iterable<User> getAllUsers();
	
	public boolean isValidUser(String email, String password);

}

