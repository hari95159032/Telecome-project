package com.telecome.project.service;

import com.telecome.project.entity.BillingIssue;

public interface BillingIssueService {
	
	public void billingIssue(BillingIssue billIssue, Integer id);

}
