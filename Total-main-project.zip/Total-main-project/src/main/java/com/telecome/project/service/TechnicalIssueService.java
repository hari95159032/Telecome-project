package com.telecome.project.service;
import com.telecome.project.entity.TechnicalIssue;

public interface TechnicalIssueService {

	
	

	 public void technicalIssue(TechnicalIssue technicalissue, Integer id);
}
