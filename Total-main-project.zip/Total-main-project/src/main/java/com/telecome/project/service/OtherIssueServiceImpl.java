package com.telecome.project.service;

import java.sql.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.telecome.project.entity.OtherIssue;
import com.telecome.project.entity.User;
import com.telecome.project.repository.OthetrIssueRepository;


@Service
public class OtherIssueServiceImpl implements OtherIssueService{
	
	OthetrIssueRepository repository;
	
	@Autowired
	public void setRepository(OthetrIssueRepository repository) {
		this.repository=repository;
	}

	@Override
	public void otherIssue(OtherIssue otherIssue, Integer id) {
		long millis=System.currentTimeMillis();
		Date currentDate = new Date(millis);
		otherIssue.setDate(currentDate);
		otherIssue.setUser(new User(id));
		repository.save(otherIssue);
		System.out.println(otherIssue.getOtherIssueId());
		
	}

}
